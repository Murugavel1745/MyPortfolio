MURUGAVEL PORTFOLIO UPGRADE

Files:
- index.html
- style.css
- script.js

IMPORTANT ASSETS:
Keep these existing files in the same GitHub repository root:
- profile.jpg.jpeg
- Murugavel-Resume.pdf

Before publishing:
1. Open index.html in a browser and check the page.
2. Replace the two sample project cards in index.html with your actual projects and repository links.
3. Check that your LinkedIn profile URL is correct. It is currently set to:
   https://linkedin.com/murugavel67

Contact form note:
The form uses mailto and opens the visitor's default email app. It does not send messages directly from the website.
